package Entity;

public class Student {
	private String parName;
	private String studentName;
	private String stuClassNo;
	private String parTel;
	private String address;
	private Integer parNo;
	private String studentSex;
	private String parPassword;
	private Integer studentId;
	private String stuClassName;
	private String headteacher;
	private String headteacherTel;
	
	
	public String getStuClassName() {
		return stuClassName;
	}
	public void setStuClassName(String stuClassName) {
		this.stuClassName = stuClassName;
	}
	public String getHeadteacher() {
		return headteacher;
	}
	public void setHeadteacher(String headteacher) {
		this.headteacher = headteacher;
	}
	public String getHeadteacherTel() {
		return headteacherTel;
	}
	public void setHeadteacherTel(String headteacherTel) {
		this.headteacherTel = headteacherTel;
	}
	public String getParName() {
		return parName;
	}
	public void setParName(String parName) {
		this.parName = parName;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStuClassNo() {
		return stuClassNo;
	}
	public void setStuClassNo(String stuClassNo) {
		this.stuClassNo = stuClassNo;
	}
	public String getParTel() {
		return parTel;
	}
	public void setParTel(String parTel) {
		this.parTel = parTel;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getParNo() {
		return parNo;
	}
	public void setParNo(Integer parNo) {
		this.parNo = parNo;
	}
	public String getStudentSex() {
		return studentSex;
	}
	public void setStudentSex(String studentSex) {
		this.studentSex = studentSex;
	}
	public String getParPassword() {
		return parPassword;
	}
	public void setParPassword(String parPassword) {
		this.parPassword = parPassword;
	}
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	
}
