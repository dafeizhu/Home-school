package Entity;

public class Teacher{
	private int teacherId;
	private String teacherName;
	private String teacherNo;
	private String teacherSex;
	private String teacherEdu;
	private String teacherObj;
	private String teacherSub;
	private String teacherIntro;
	private String TeaLogin;
	
	public int getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(int teacherId) {
		this.teacherId = teacherId;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public String getTeacherNo() {
		return teacherNo;
	}
	public void setTeacherNo(String teacherNo) {
		this.teacherNo = teacherNo;
	}
	public String getTeacherSex() {
		return teacherSex;
	}
	public void setTeacherSex(String teacherSex) {
		this.teacherSex = teacherSex;
	}
	public String getTeacherEdu() {
		return teacherEdu;
	}
	public void setTeacherEdu(String teacherEdu) {
		this.teacherEdu = teacherEdu;
	}
	public String getTeacherObj() {
		return teacherObj;
	}
	public void setTeacherObj(String teacherObj) {
		this.teacherObj = teacherObj;
	}
	public String getTeacherSub() {
		return teacherSub;
	}
	public void setTeacherSub(String teacherSub) {
		this.teacherSub = teacherSub;
	}
	public String getTeacherIntro() {
		return teacherIntro;
	}
	public void setTeacherIntro(String teacherIntro) {
		this.teacherIntro = teacherIntro;
	}
	public String getTeaLogin() {
		return TeaLogin;
	}
	public void setTeaLogin(String teaLogin) {
		TeaLogin = teaLogin;
	}
}

