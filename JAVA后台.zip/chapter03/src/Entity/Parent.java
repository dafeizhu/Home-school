package Entity;

public class Parent {
	private String parName;
	private String parTel;
	private Integer parNo;
	private String sex;
	private String parLogin;
	private Integer parId;
	
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public Integer getParId() {
		return parId;
	}
	public void setParId(Integer parId) {
		this.parId = parId;
	}
	public String getParName() {
		return parName;
	}
	public void setParName(String parName) {
		this.parName = parName;
	}
	public String getParTel() {
		return parTel;
	}
	public void setParTel(String parTel) {
		this.parTel = parTel;
	}
	public Integer getParNo() {
		return parNo;
	}
	public void setParNo(Integer parNo) {
		this.parNo = parNo;
	}
	public String getParLogin() {
		return parLogin;
	}
	public void setParLogin(String parLogin) {
		this.parLogin = parLogin;
	}
}
