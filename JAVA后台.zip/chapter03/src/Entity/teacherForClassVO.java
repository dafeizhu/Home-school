package Entity;

public class teacherForClassVO {
	private String currentClassNo;
	private String className;
	public String getCurrentClassNo() {
		return currentClassNo;
	}
	public void setCurrentClassNo(String currentClassNo) {
		this.currentClassNo = currentClassNo;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}


}
