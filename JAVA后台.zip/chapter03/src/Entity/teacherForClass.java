package Entity;

public class teacherForClass {
	private Integer teacherNo;
	private Integer classNo;
	private String grade;
	private String teacherName;
	public Integer getTeacherNo() {
		return teacherNo;
	}
	public void setTeacherNo(Integer teacherNo) {
		this.teacherNo = teacherNo;
	}
	public Integer getClassNo() {
		return classNo;
	}
	public void setClassNo(Integer classNo) {
		this.classNo = classNo;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	
	
}
