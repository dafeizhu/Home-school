package Server.service;

public interface ITchLoginSevice {
	/**
	 * ��ʦ��¼
	 * @param username
	 * @param password
	 */
	public boolean login(String teacherNo, String LoginPW);	
}
