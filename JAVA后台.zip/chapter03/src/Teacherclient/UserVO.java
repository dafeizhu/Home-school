package Teacherclient;

public class UserVO {
	private String CurrentClassNo;
	private String ClassName;
	public String getCurrentClassNo() {
		return CurrentClassNo;
	}
	public void setCurrentClassNo(String currentClassNo) {
		CurrentClassNo = currentClassNo;
	}
	public String getClassName() {
		return ClassName;
	}
	public void setClassName(String className) {
		ClassName = className;
	}


}
